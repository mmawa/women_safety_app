List sweetSayings = [
  "Your presence, lights up the whole room",
  "We admire,Your strong personality.",
  "We'll help you In any way we can.",
  "You are Strong and courageous",
  'I say if Im beautiful. I say if Im strong',
  'Above all, be the heroine of your life, not the victim',
];

List<String> articleTitle = [
  "Stay Strong . Stand up . Have a voice",
  "We have to end Violance",
  "Indian women are inspiring country",
  "You are strong"
];
List<String> imageSliders = [
  "https://media.istockphoto.com/photos/trainer-explaining-or-guiding-to-cut-clothes-to-group-of-women-at-picture-id1395862191?k=20&m=1395862191&s=612x612&w=0&h=OT9Nddr3aZxkOX1JG_Hi55xUq_0ceh8RRAcHSMK5ZQo=",
  "https://media.istockphoto.com/photos/stop-violence-businessman-showing-a-sign-picture-id605774650?k=20&m=605774650&s=612x612&w=0&h=r5ePGAJpMDo4sr0nIez7vyhRNakjGhhww86W0govyY8=",
  "https://media.istockphoto.com/photos/female-models-of-different-ages-celebrating-their-natural-bodies-picture-id1335187854?k=20&m=1335187854&s=612x612&w=0&h=LRqxkLRl4yHRhsWjcZEyNsDvmvR1XL4j3taeOndZvjo=",
  "https://media.istockphoto.com/photos/an-adult-woman-shows-strength-picture-id1213656551?k=20&m=1213656551&s=612x612&w=0&h=5cRv9vHDbgC6uQyVFrK-EhsCmz_V04vvkROGvFYVvFk=",
];
