package com.example.naari

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
